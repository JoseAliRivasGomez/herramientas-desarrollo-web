Hi, 

All the images are free to use, but not to sale.

You can find more here:
http://www.iconspedia.com/