========================================
	
	Change log
	
	Current Version: Metro Modal v2.1
	Author: Klerith
	Support page: http://codecanyon.net/user/klerith
	More products: http://codecanyon.net/user/klerith/portfolio
	
	
========================================

If you are updating from v1 to v2, please check the documentation, because I made Huge Changes.

V.2.1
* Fix some iframe overflow.


V.2

* I remove the dependency from jQuery UI (Drag is not avalaible, but we have super light js)
* Refactor all the CSS and JS
* New Function to close all Modals
* Huge improvements on div converter into modal, READ AND CHECK the tutorials please. I change a couple of things. Now is simplier, but different
* New properties added
	- position
	- top, left, right, bottom
	- backshadow
	- iframecache
	- loadingtext
	- youtube
	- youtubecontrols
	- youtubeinfo
	- vimeo
	- googlelatitud
	- googlelongitud
	- googlezoom
	- googlemaptypeid
	- mobilehidebuttons
	- uniqueclasstomodal
	- colorchangespeed
	- Integration with Google Maps Api (Optional)
	- Vimeo Support
* New Youtube Features
* New Style
* Metro Modal can appear anywhere on the screen.
* New functionallity when the user Closes, Maximize or Minimize the Metro Modal
* Click outside on touch enabled devices can't be better
* Updates on the Changing color functions.
* New animations on resize window.
 
 
